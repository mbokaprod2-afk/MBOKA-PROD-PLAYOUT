MBOKA PROD PLAYOUT — V9

Correction : suppression de la propriété buildResources non reconnue par electron-builder 26.15.3.

1. Extraire TOUT le ZIP.
2. Double-cliquer sur BUILD-SETUP-WINDOWS.cmd.
3. Le script installe les dépendances et lance electron-builder localement.
4. Le résultat est dans dist\MBOKA_PROD_PLAYOUT_Setup.exe.
