MBOKA PROD PLAYOUT V11 — CORRECTION DU BOUTON NOM

Le bouton ✏️ Nom ouvre maintenant un éditeur directement dans l'interface.
1. Sélectionnez un canal.
2. Cliquez sur ✏️ Nom.
3. Modifiez le nom.
4. Cliquez sur ✓ Enregistrer.
5. Le nouveau nom est conservé dans la configuration du canal.

Entrée = enregistrer. Échap = annuler.
