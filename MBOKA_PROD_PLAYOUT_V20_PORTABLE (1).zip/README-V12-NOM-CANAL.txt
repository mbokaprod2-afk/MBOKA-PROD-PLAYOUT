MBOKA PROD PLAYOUT V12 — BOUTON NOM ACTIF

Le bouton ✏️ Nom est maintenant relié explicitement au code de l'application Electron.

1. Sélectionner un canal.
2. Cliquer sur ✏️ Nom.
3. Modifier le nom.
4. Cliquer sur ✓ Enregistrer.
5. Le nom est immédiatement affiché dans la liste et dans l'en-tête.
6. Entrée = enregistrer ; Échap = annuler.

Une protection a aussi été ajoutée contre une configuration localStorage corrompue qui pouvait empêcher les boutons de fonctionner.
