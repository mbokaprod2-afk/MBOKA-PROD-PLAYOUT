MBOKA PROD PLAYOUT V20 - BASE V12

IMPORTANT :
Cette version ne contient plus les anciens fichiers SETUP qui provoquaient
la confusion.

1. Clic droit sur le ZIP > Extraire tout...
2. Ouvre le dossier extrait.
3. Double-clique uniquement sur CREER_EXE_PORTABLE.cmd.
4. Le script utilise directement C:\Program Files\nodejs\node.exe
   si Node.js est installé, même si le PATH Windows n'est pas encore à jour.
5. Après compilation :
   dist\MBOKA_PROD_PLAYOUT_Portable.exe

L'EXE final n'a pas besoin de Node.js.
Node.js et Internet sont nécessaires uniquement pour fabriquer l'EXE.
