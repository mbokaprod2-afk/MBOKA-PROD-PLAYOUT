const defaultNames=[
"MBOKA PROD TV","MBOKA CINÉMA","MBOKA MUSIQUE","MBOKA GOSPEL","SÉRIES AFRICAINES",
"CINÉMA AFRICAIN","DIVERTISSEMENT","CULTURE AFRICAINE","DÉCOUVERTE","ÉVÉNEMENTS",
"JEUNESSE","ACTUALITÉS / MAGAZINE","DOCUMENTAIRES","RADIO / MUSIC","CANAL ÉVÉNEMENTIEL"
];
let saved=null;
try { saved=JSON.parse(localStorage.getItem("mbokaChannels")||"null"); } catch(e) { localStorage.removeItem("mbokaChannels"); saved=null; }
let channels=(Array.isArray(saved)&&saved.length===15)?saved:defaultNames.map((name,i)=>({id:i+1,name,logo:null,items:[],settings:{streamKey:"",rtmpUrl:"",hlsUrl:"",videoBitrate:"2500k",audioBitrate:"128k",engine:"ffmpeg"}}));
let current=0,currentItem=0,autoPlay=false,loopPlay=false;
let liveChannels=new Set();
const channelsEl=document.getElementById("channels"),playlistEl=document.getElementById("playlist");
const preview=document.getElementById("preview"),program=document.getElementById("program"),hlsPlayer=document.getElementById("hlsPlayer");

function persist(){localStorage.setItem("mbokaChannels",JSON.stringify(channels.map(c=>({...c,logo:null}))));}
function renderChannels(){
 channelsEl.innerHTML=channels.map((c,i)=>`<div class="channel ${i===current?'selected':''} ${liveChannels.has(i)?'live-selected':''}" onclick="selectChannel(${i})">
 <div class="channel-main"><b>CANAL ${String(c.id).padStart(2,'0')}</b> — ${escapeHtml(c.name)}
 <small>${c.items.length} élément(s) • ${c.settings?.hlsUrl?'HLS configuré':'HLS non configuré'}</small></div>
 <button class="live-action ${liveChannels.has(i)?'active':''}" onclick="event.stopPropagation();toggleLiveChannel(${i})">${liveChannels.has(i)?'🔴 LIVE ON':'⚪ LIVE'}</button>
 </div>`).join("");
}
function renderPlaylist(){
 const c=channels[current]; document.getElementById("channelTitle").textContent=`CANAL ${c.id} — ${c.name}`;
 playlistEl.innerHTML=c.items.length?c.items.map((x,i)=>`<div class="item ${i===currentItem?'active':''}">
 <div class="num">${String(i+1).padStart(2,'0')}</div><div><b>${escapeHtml(x.name)}</b><small>${x.type} • ${x.url?'fichier local':'aucun média'}</small></div>
 <button onclick="loadItem(${i})">▶ Préparer</button></div>`).join(""):`<div class="item"><div></div><div><b>Playlist vide</b><small>Ajoutez des vidéos avec le bouton ＋ Vidéo.</small></div><div></div></div>`;
 loadSettings();
}

function toggleLiveChannel(i){
 if(liveChannels.has(i)) liveChannels.delete(i); else liveChannels.add(i);
 renderChannels();
}
function selectAllLive(){channels.forEach((_,i)=>liveChannels.add(i));renderChannels();}
function clearAllLive(){liveChannels.clear();renderChannels();}

function selectChannel(i){current=i;currentItem=0;renderChannels();renderPlaylist();updatePlaybackButtons();resetPreview();}
function resetPreview(){preview.removeAttribute("src");preview.load();document.getElementById("previewEmpty").style.display="block";}
function loadItem(i){currentItem=i;const x=channels[current].items[i];if(x.url){preview.src=x.url;preview.load();document.getElementById("previewEmpty").style.display="none";}renderPlaylist();}
function playPreview(){if(channels[current].items[currentItem]){loadItem(currentItem);preview.play().catch(()=>{});}}
function pausePreview(){preview.pause()}
function goOnAir(){const x=channels[current].items[currentItem];if(!x||!x.url){alert("Ajoutez ou sélectionnez une vidéo avant de l'envoyer ON AIR.");return}program.src=x.url;program.play().catch(()=>{});}
function nextItem(){const c=channels[current];if(!c.items.length)return;currentItem=(currentItem+1)%c.items.length;loadItem(currentItem);goOnAir();}
function shufflePlaylist(){const c=channels[current];if(c.items.length<2)return;for(let i=c.items.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[c.items[i],c.items[j]]=[c.items[j],c.items[i]];}currentItem=0;persist();renderPlaylist();if(autoPlay)playPreview();}
function shuffleVideo(){const c=channels[current];if(!c.items.length){alert("Ajoutez des vidéos dans la playlist.");return;}currentItem=Math.floor(Math.random()*c.items.length);loadItem(currentItem);if(autoPlay)playPreview();else preview.play().catch(()=>{});goOnAir();}
function stopAll(){preview.pause();program.pause();}
function updatePlaybackButtons(){
 const a=document.getElementById("autoPlayBtn"),l=document.getElementById("loopBtn");
 if(a)a.textContent=`▶️ LECTURE AUTOMATIQUE : ${autoPlay?"ON":"OFF"}`;
 if(l)l.textContent=`🔁 LECTURE EN BOUCLE : ${loopPlay?"ON":"OFF"}`;
}
function toggleAutoPlay(){autoPlay=!autoPlay;updatePlaybackButtons();}
function toggleLoop(){loopPlay=!loopPlay;updatePlaybackButtons();preview.loop=loopPlay;program.loop=loopPlay;}
function handleVideoEnd(){
 if(loopPlay){return;}
 if(autoPlay){
   const c=channels[current];
   if(c.items.length){currentItem=(currentItem+1)%c.items.length;loadItem(currentItem);preview.play().catch(()=>{});goOnAir();}
 }
}
preview.addEventListener("ended",handleVideoEnd);
program.addEventListener("ended",()=>{
 if(loopPlay)return;
 if(autoPlay){const c=channels[current];if(c.items.length){currentItem=(currentItem+1)%c.items.length;loadItem(currentItem);goOnAir();}}
});
function renameChannel(){
 const c=channels[current];
 const editor=document.getElementById("nameEditor");
 const input=document.getElementById("channelNameInput");
 if(!c||!editor||!input){alert("Le panneau de modification du nom est indisponible.");return;}
 input.value=c.name||"";
 editor.hidden=false;
 editor.style.display="flex";
 requestAnimationFrame(()=>{input.focus();input.select();});
}
function saveChannelName(){
 const input=document.getElementById("channelNameInput");
 const editor=document.getElementById("nameEditor");
 if(!input||!editor)return;
 const n=input.value.trim();
 if(!n){alert("Veuillez saisir un nom pour le canal.");input.focus();return;}
 channels[current].name=n;
 persist();
 editor.hidden=true;
 editor.style.display="none";
 renderChannels();
 renderPlaylist();
}
function cancelChannelName(){
 const editor=document.getElementById("nameEditor");
 if(editor){editor.hidden=true;editor.style.display="none";}
}

// Les boutons sont reliés explicitement pour garantir leur fonctionnement dans Electron.
document.addEventListener("DOMContentLoaded",()=>{
 const renameBtn=document.getElementById("renameBtn");
 const saveBtn=document.getElementById("saveNameBtn");
 const cancelBtn=document.getElementById("cancelNameBtn");
 const input=document.getElementById("channelNameInput");
 if(renameBtn) renameBtn.addEventListener("click",renameChannel);
 if(saveBtn) saveBtn.addEventListener("click",saveChannelName);
 if(cancelBtn) cancelBtn.addEventListener("click",cancelChannelName);
 if(input) input.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();saveChannelName();} if(e.key==="Escape")cancelChannelName();});
});
function changeLogo(){document.getElementById("logoInput").click()}
document.getElementById("logoInput").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;channels[current].logo=URL.createObjectURL(f);renderChannels();});
function addVideo(){document.getElementById("videoInput").click()}
document.getElementById("videoInput").addEventListener("change",e=>{[...e.target.files].forEach(f=>channels[current].items.push({name:f.name,type:"VIDÉO",url:URL.createObjectURL(f)}));renderChannels();renderPlaylist();updatePlaybackButtons();});
function settings(){const c=channels[current];c.settings=c.settings||{};return c.settings}
function loadSettings(){
 const s=settings(); document.getElementById("streamKey").value=s.streamKey||"";document.getElementById("rtmpUrl").value=s.rtmpUrl||"";
 document.getElementById("hlsUrl").value=s.hlsUrl||"";document.getElementById("videoBitrate").value=s.videoBitrate||"2500k";
 document.getElementById("audioBitrate").value=s.audioBitrate||"128k";document.getElementById("engine").value=s.engine||"ffmpeg";updateCommand();
}
async function saveSettings(){
 const s=settings();s.rtmpUrl=document.getElementById("rtmpUrl").value.trim();s.hlsUrl=document.getElementById("hlsUrl").value.trim();
 s.videoBitrate=document.getElementById("videoBitrate").value.trim()||"2500k";s.audioBitrate=document.getElementById("audioBitrate").value.trim()||"128k";s.engine=document.getElementById("engine").value;
 const key=document.getElementById("streamKey").value;
 if(window.mbokaSecure?.setStreamKey){await window.mbokaSecure.setStreamKey(current,key);s.streamKey="__SECURE__";}else{s.streamKey=key;}
 persist();renderChannels();updateCommand();document.getElementById("saveStatus").textContent="✓ Paramètres enregistrés";
 setTimeout(()=>document.getElementById("saveStatus").textContent="",2500);
}
async function loadSecureKey(){if(window.mbokaSecure?.getStreamKey){const k=await window.mbokaSecure.getStreamKey(current);if(k!==null)document.getElementById("streamKey").value=k;}}
function toggleKey(){const e=document.getElementById("streamKey");e.type=e.type==="password"?"text":"password";event.target.textContent=e.type==="password"?"Afficher":"Masquer"}
function updateCommand(){
 const s=settings(),base=(s.rtmpUrl||"rtmp://serveur/app").replace(/\/$/,""),key=document.getElementById("streamKey").value||"{key}";
 const target=base.includes("{key}")?base.replace("{key}",key):base+"/"+key;
 document.getElementById("ffmpegCommand").textContent=`ffmpeg -re -i INPUT.mp4 -c:v libx264 -b:v ${s.videoBitrate||"2500k"} -c:a aac -b:a ${s.audioBitrate||"128k"} -f flv "${target}"`;
}
function loadHls(){
 const url=document.getElementById("hlsUrl").value.trim(); if(!url){alert("Ajoutez une URL HLS .m3u8.");return}
 hlsPlayer.src=url;document.getElementById("hlsEmpty").style.display="none";hlsPlayer.play().catch(()=>{});
}
function clearHls(){hlsPlayer.removeAttribute("src");hlsPlayer.load();document.getElementById("hlsEmpty").style.display="block"}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
renderChannels();renderPlaylist();updatePlaybackButtons();

function openInstallGuide(){document.getElementById('installGuide').hidden=false;}
function closeInstallGuide(){document.getElementById('installGuide').hidden=true;}
