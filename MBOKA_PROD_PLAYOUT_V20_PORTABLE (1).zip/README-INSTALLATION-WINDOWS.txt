MBOKA PROD PLAYOUT V10 — INSTALLATION WINDOWS

IMPORTANT
---------
Ce ZIP contient le projet source et le script de compilation. Il ne contient pas encore le fichier MBOKA_PROD_PLAYOUT_Setup.exe.

POUR CREER LE VRAI INSTALLATEUR WINDOWS
---------------------------------------
1. Extrayez tout le ZIP dans un dossier, par exemple :
   C:\MBOKA_PROD_PLAYOUT
2. Ouvrez le dossier extrait.
3. Double-cliquez sur BUILD-SETUP-WINDOWS.cmd.
4. Le script vérifie Node.js et npm.
5. Si Node.js manque et que winget est disponible, le script tente d'installer Node.js LTS.
6. Relancez le script après l'installation de Node.js.
7. Le script installe les dépendances et Electron Builder.
8. Le fichier final doit être créé ici :
   dist\MBOKA_PROD_PLAYOUT_Setup.exe

INSTALLATION DU PROGRAMME FINAL
--------------------------------
Une fois le Setup EXE créé, double-cliquez uniquement sur :
MBOKA_PROD_PLAYOUT_Setup.exe

L'utilisateur final n'a alors besoin ni de Node.js, ni de npm.
