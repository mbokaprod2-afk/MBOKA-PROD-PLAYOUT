const {app,BrowserWindow,ipcMain,safeStorage} = require("electron");
const path=require("path"), fs=require("fs");
let win;
const storePath=path.join(app.getPath("userData"),"stream-keys.json");
function readStore(){try{return JSON.parse(fs.readFileSync(storePath,"utf8"))}catch{return {}}}
function writeStore(x){fs.writeFileSync(storePath,JSON.stringify(x),"utf8")}
function createWindow(){
 win=new BrowserWindow({width:1500,height:950,minWidth:1000,minHeight:700,webPreferences:{preload:path.join(__dirname,"preload.js"),contextIsolation:true,nodeIntegration:false}});
 win.loadFile("index.html");
}
ipcMain.handle("secure:set",(_,channel,key)=>{
 const s=readStore(); s[String(channel)]=safeStorage.isEncryptionAvailable()?safeStorage.encryptString(key).toString("base64"):key; s[String(channel)+"_encrypted"]=safeStorage.isEncryptionAvailable(); writeStore(s); return true;
});
ipcMain.handle("secure:get",(_,channel)=>{
 const s=readStore(),v=s[String(channel)]; if(v==null)return null;
 try{return s[String(channel)+"_encrypted"]?safeStorage.decryptString(Buffer.from(v,"base64")):v}catch{return null}
});
app.whenReady().then(createWindow);
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit()});
