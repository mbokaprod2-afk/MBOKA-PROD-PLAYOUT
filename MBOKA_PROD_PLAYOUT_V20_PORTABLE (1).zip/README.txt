MBOKA PROD PLAYOUT — 15 CANAUX
=================================

Cette archive contient une interface web de démonstration d'une régie Playout
MBOKA PROD avec 15 canaux.

FONCTIONS INCLUSES
- 15 canaux préconfigurés
- Renommage facile de chaque canal
- Ajout de logo par canal
- Ajout de vidéos dans la playlist
- Preview / Program (ON AIR)
- Play / Pause / Stop / Suivant
- Passage automatique au programme suivant
- Interface responsive ordinateur/téléphone

INSTALLATION
1. Décompresser le ZIP.
2. Ouvrir index.html dans Chrome, Edge ou Firefox.
3. Sélectionner un canal.
4. Cliquer sur « + Vidéo » pour ajouter des fichiers.
5. Sélectionner une vidéo puis « ENVOYER ON AIR ».

IMPORTANT
Cette version est une base fonctionnelle côté navigateur. Elle ne fournit pas
à elle seule une sortie RTMP 24h/24 vers un serveur distant. Pour une vraie
diffusion professionnelle 15 canaux, il faudra ajouter un serveur Playout/
FFmpeg et une couche backend de diffusion (RTMP/SRT/HLS) ainsi que la gestion
persistante des playlists et des droits administrateur.


NOUVEAU — RÉGLAGES RTMP / HLS / FFMPEG
---------------------------------------
Chaque canal possède maintenant :
- Clé RTMP / Stream Key propre au canal avec Afficher/Masquer.
- Stockage chiffré via Electron safeStorage lorsque Windows le permet.
- URL RTMP de base : rtmp://serveur/app ou rtmp://serveur/app/{key}.
- URL du lecteur HLS du site (.m3u8) avec bouton de test.
- Débit vidéo FFmpeg (ex. 2500k).
- Débit audio FFmpeg (ex. 128k).
- Choix du moteur : FFmpeg, lecteur navigateur ou FFmpeg externe/serveur.
- Génération automatique d'une commande FFmpeg adaptée au canal.

MODE WINDOWS
------------
Pour utiliser le stockage chiffré Windows :
1. Installer Node.js.
2. Dans le dossier du projet : npm install
3. Puis : npm start

Le bouton « Enregistrer » chiffre la clé via Electron safeStorage lorsque
le système fournit un backend de chiffrement. En ouverture directe de
index.html, la clé utilise le stockage navigateur comme solution de repli.

IMPORTANT RTMP
--------------
Le navigateur ne peut pas, à lui seul, envoyer directement une sortie RTMP
vers un serveur. Le réglage RTMP prépare la destination et la commande FFmpeg.
Pour une diffusion réelle, FFmpeg doit être lancé sur Windows ou sur un
serveur Playout. Le lecteur HLS lit le flux .m3u8 publié par le serveur.
