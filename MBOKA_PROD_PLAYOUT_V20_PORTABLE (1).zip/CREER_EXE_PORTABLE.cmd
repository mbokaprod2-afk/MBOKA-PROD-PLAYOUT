@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title MBOKA PROD PLAYOUT - CREATION EXE PORTABLE

if not exist "%~dp0package.json" (
  echo.
  echo ERREUR : package.json introuvable.
  echo Ouvre ce fichier depuis le dossier extrait du ZIP.
  echo.
  pause
  exit /b 1
)

set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
set "NPM_CMD=%ProgramFiles%\nodejs\npm.cmd"

if not exist "%NODE_EXE%" (
  set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"
  set "NPM_CMD=%ProgramFiles(x86)%\nodejs\npm.cmd"
)

if not exist "%NODE_EXE%" (
  echo.
  echo ERREUR : Node.js est introuvable.
  echo.
  echo Le programme cherche :
  echo C:\Program Files\nodejs\node.exe
  echo.
  echo Si Node.js vient d'etre installe, redemarre Windows.
  echo.
  pause
  exit /b 1
)

if not exist "%NPM_CMD%" (
  echo.
  echo ERREUR : npm.cmd est introuvable.
  echo.
  pause
  exit /b 1
)

echo.
echo ================================================
echo   MBOKA PROD PLAYOUT - EXE PORTABLE
echo ================================================
echo.
echo Node.js :
"%NODE_EXE%" -v
echo.
echo npm :
call "%NPM_CMD%" -v
echo.

if not exist "%~dp0node_modules\electron\package.json" (
  echo Installation des composants Electron...
  echo Une connexion Internet est necessaire.
  echo.
  call "%NPM_CMD%" install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo ERREUR : npm install a echoue.
    echo Verifie la connexion Internet.
    echo.
    pause
    exit /b 1
  )
)

echo.
echo Creation de MBOKA_PROD_PLAYOUT_Portable.exe...
echo.

call "%NPM_CMD%" run dist:portable
if errorlevel 1 (
  echo.
  echo ERREUR : la compilation a echoue.
  echo.
  pause
  exit /b 1
)

if exist "%~dp0dist\MBOKA_PROD_PLAYOUT_Portable.exe" (
  echo.
  echo ================================================
  echo   SUCCES
  echo ================================================
  echo.
  echo EXE :
  echo %~dp0dist\MBOKA_PROD_PLAYOUT_Portable.exe
  echo.
  echo Le fichier est portable : aucune installation
  echo n'est necessaire pour l'utilisateur final.
  echo.
  explorer "%~dp0dist"
) else (
  echo.
  echo ERREUR : le fichier EXE n'a pas ete cree.
)

echo.
pause
