const {contextBridge,ipcRenderer}=require("electron");
contextBridge.exposeInMainWorld("mbokaSecure",{setStreamKey:(channel,key)=>ipcRenderer.invoke("secure:set",channel,key),getStreamKey:(channel)=>ipcRenderer.invoke("secure:get",channel)});
